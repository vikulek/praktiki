﻿using System;

namespace prakt6_var1
{
	public class person
	{

		private string name;
		private string surname;
		private DateTime bdate;
		public person(string _name, string _surname, DateTime _bdate)
		{
			name = _name;
			surname = _surname;
			bdate = _bdate;
		}
	}
}
