﻿//Петов Всеволод, БББО-02-19
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GFG
{

    class Program
    { 
        static void Main(string[] args)
        {
            //Вступление
            Console.Beep(659, 600);
            Console.Beep(523, 600);
            Console.Beep(494, 600);
            Console.Beep(440, 600);
            Console.Beep(392, 300);
            Console.Beep(494, 300);
            Console.Beep(370, 300);
            Console.Beep(494, 300);
            Console.Beep(330, 500);
            Thread.Sleep(300);
            //Наступает минута прощания, ты глядишь мне тревожно в глаза
            Console.Beep(494, 400);
            Console.Beep(523, 200);
            Console.Beep(494, 800);
            Console.Beep(392, 400);
            Console.Beep(370, 200);
            Console.Beep(330, 800);
            Console.Beep(311, 400);
            Console.Beep(330, 200);
            Console.Beep(370, 1000);
            Console.Beep(311, 300);
            Console.Beep(247, 400);
            Thread.Sleep(300);
            Console.Beep(494, 400);
            Console.Beep(523, 200);
            Console.Beep(494, 800);
            Console.Beep(466, 400);
            Console.Beep(494, 200);
            Console.Beep(740, 800);
            Console.Beep(784, 400);
            Console.Beep(740, 200);
            Console.Beep(660, 1000);
            Thread.Sleep(300);
            //И ловлю я родное дыхание
            Console.Beep(660, 400);
            Console.Beep(622, 200);
            Console.Beep(740, 800);
            Console.Beep(660, 400);
            Console.Beep(523, 200);
            Console.Beep(440, 800);
            Console.Beep(523, 400);
            Console.Beep(660, 200);
            Console.Beep(494, 1000);
            Console.Beep(392, 200);
            Console.Beep(330, 800);
            //А вдали уже дышит гроза
            Console.Beep(493, 400);
            Console.Beep(523, 200);
            Console.Beep(494, 800);
            Console.Beep(311, 400);
            Console.Beep(370, 200);
            Console.Beep(494, 800);
            Console.Beep(370, 400);
            Console.Beep(392, 200);
            Console.Beep(330, 800);
            Thread.Sleep(300);
            //Дрогнул воздух туманный и синий
            Console.Beep(494, 400);
            Console.Beep(523, 200);
            Console.Beep(494, 800);
            Console.Beep(392, 400);
            Console.Beep(370, 200);
            Console.Beep(330, 800);
            Console.Beep(311, 400);
            Console.Beep(330, 200);
            Console.Beep(370, 1000);
            Console.Beep(311, 300);
            Console.Beep(247, 400);
            Thread.Sleep(300);
            //И тревога коснулась висков
            Console.Beep(494, 400);
            Console.Beep(523, 200);
            Console.Beep(494, 800);
            Console.Beep(466, 400);
            Console.Beep(494, 200);
            Console.Beep(740, 800);
            Console.Beep(784, 400);
            Console.Beep(740, 200);
            Console.Beep(660, 1000);
            Thread.Sleep(300);
            //И зовёт нас на подвиг Россия
            Console.Beep(660, 400);
            Console.Beep(622, 200);
            Console.Beep(740, 800);
            Console.Beep(660, 400);
            Console.Beep(523, 200);
            Console.Beep(440, 800);
            Console.Beep(523, 400);
            Console.Beep(660, 200);
            Console.Beep(494, 1000);
            Console.Beep(392, 200);
            Console.Beep(330, 800);
            //Веет ветром от шага полков
            Console.Beep(494, 400);
            Console.Beep(523, 200);
            Console.Beep(494, 800);
            Console.Beep(311, 400);
            Console.Beep(370, 200);
            Console.Beep(494, 800);
            Console.Beep(370, 400);
            Console.Beep(392, 200);
            Console.Beep(330, 800);
            Thread.Sleep(600);
            //Прощай отчий край
            Console.Beep(247, 600);
            Console.Beep(392, 1400);
            Console.Beep(370, 400);
            Console.Beep(330, 100);
            Console.Beep(370, 1400);
            Thread.Sleep(300);
            //Ты нас вспоминай
            Console.Beep(247, 600);
            Console.Beep(370, 1400);
            Console.Beep(392, 400);
            Console.Beep(370, 100);
            Console.Beep(330, 1400);
            Thread.Sleep(300);
            //Прощай милый взгляд, прости - прощай, прости - прощай
            Console.Beep(247, 600);
            Console.Beep(330, 1400);
            Console.Beep(370, 400);
            Console.Beep(330, 100);
            Console.Beep(440, 1400);
            Console.Beep(440, 300);
            Console.Beep(494, 300);
            Console.Beep(523, 300);
            Console.Beep(494, 600);
            Console.Beep(370, 600);
            Console.Beep(392, 1000);
            Console.Beep(370, 300);
            Console.Beep(330, 1400);
            Thread.Sleep(300);
            //Летят летят года
            Console.Beep(494, 600);
            Console.Beep(784, 600);
            Console.Beep(740, 600);
            Console.Beep(494, 600);
            Console.Beep(392, 600);
            Console.Beep(370, 1400);
            Thread.Sleep(300);
            //Уходят во мглу поезда, а в них солдаты. И в небе тёмном горит солдатская звезда
            Console.Beep(494, 600);
            Console.Beep(740, 600);
            Console.Beep(622, 400);
            Console.Beep(494, 200);
            Console.Beep(740, 600);
            Console.Beep(784, 400);
            Console.Beep(740, 200);
            Console.Beep(660, 1400);
            Console.Beep(494, 300);
            Console.Beep(523, 300);
            Console.Beep(494, 300);
            Console.Beep(440, 600);
            Console.Beep(740, 900);
            Console.Beep(440, 300);
            Console.Beep(494, 300);
            Console.Beep(440, 300);
            Console.Beep(392, 600);
            Console.Beep(660, 900);
            Console.Beep(392, 300);
            Console.Beep(440, 300);
            Console.Beep(392, 300);
            Console.Beep(370, 600);
            Console.Beep(523, 600);
            Console.Beep(494, 600);
            Console.Beep(311, 600);
            Console.Beep(330, 1000);
            //А в них солдаты и в небе тёмном горит солдатская звезда
            Console.Beep(587, 300);
            Console.Beep(523, 300);
            Console.Beep(494, 300);
            Console.Beep(440, 600);
            Console.Beep(740, 900);
            Console.Beep(440, 300);
            Console.Beep(494, 300);
            Console.Beep(440, 300);
            Console.Beep(392, 600);
            Console.Beep(659, 900);
            Console.Beep(392, 300);
            Console.Beep(440, 300);
            Console.Beep(392, 300);
            Console.Beep(370, 600);
            Console.Beep(523, 600);
            Console.Beep(494, 600);
            Console.Beep(622, 600);
            Console.Beep(659, 1500);
            //Прощай отчий край
            Console.Beep(247, 600);
            Console.Beep(392, 1400);
            Console.Beep(370, 400);
            Console.Beep(330, 100);
            Console.Beep(370, 1400);
            Thread.Sleep(300);
            //Ты нас вспоминай
            Console.Beep(247, 600);
            Console.Beep(370, 1400);
            Console.Beep(392, 400);
            Console.Beep(370, 100);
            Console.Beep(330, 1400);
            Thread.Sleep(300);
            //Прощай милый взгляд, не все из нас придут назад
            Console.Beep(247, 600);
            Console.Beep(330, 1400);
            Console.Beep(370, 400);
            Console.Beep(330, 100);
            Console.Beep(440, 1400);
            Console.Beep(440, 300);
            Console.Beep(494, 300);
            Console.Beep(523, 300);
            Console.Beep(494, 600);
            Console.Beep(370, 600);
            Console.Beep(392, 1000);
            Console.Beep(370, 300);
            Console.Beep(330, 1400);
            Thread.Sleep(300);
        }
    }
}