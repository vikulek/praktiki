﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DotChatWF
{
  public partial class AuthentificationForm : Form
  {
    public AuthentificationForm()
    {
      InitializeComponent();
    }

    private void button1_Click(object sender, EventArgs e)
    {

    }
  }
}
